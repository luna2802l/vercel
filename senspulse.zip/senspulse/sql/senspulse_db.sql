-- ═══════════════════════════════════════════════════════
--  SensPulse Pro — Base de datos MySQL
--  Importar desde phpMyAdmin o ejecutar en MySQL
-- ═══════════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS senspulse CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE senspulse;

-- ── Tabla de usuarios ──────────────────────────────────
CREATE TABLE IF NOT EXISTS usuarios (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  nombre     VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  rol        VARCHAR(50)  DEFAULT 'Médico',
  creado_en  DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Usuario demo (contraseña: senspulse2026)
INSERT IGNORE INTO usuarios (nombre, email, password, rol) VALUES
  ('Doctor Luna', 'admin@senspulse.demo', SHA2('senspulse2026', 256), 'Administrador');

-- ── Tabla de casos clínicos ────────────────────────────
CREATE TABLE IF NOT EXISTS casos (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  paciente      VARCHAR(150) NOT NULL,
  edad          VARCHAR(10),
  sexo          VARCHAR(20),
  sintomas      TEXT,
  riesgos       TEXT,
  temperatura   VARCHAR(20),
  titulo        VARCHAR(200),
  texto_result  TEXT,
  score         INT          DEFAULT 0,
  prioridad     VARCHAR(30),
  estado        VARCHAR(50),
  operador      VARCHAR(150),
  chart_values  VARCHAR(50),
  trend_values  VARCHAR(100),
  tags          VARCHAR(255),
  color_class   VARCHAR(20),
  creado_en     DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Casos demo de muestra
INSERT IGNORE INTO casos (id, paciente, edad, sexo, sintomas, riesgos, temperatura, titulo, texto_result, score, prioridad, estado, operador, chart_values, trend_values, tags, color_class) VALUES
  (10001, 'Ana Torres',  '29', 'Femenino',  'fiebre, tos',        'contacto con enfermo', '38.9°C', 'Atención respiratoria',    'Monitoreo inmediato por fiebre y tos frecuente.',               82, 'Alta',    'En observación', 'Sistema demo', '56,12,8,24',  '25,44,76,63', 'Respiratorio,Guardado',  'rose'),
  (10002, 'Luis Mejía',  '44', 'Masculino', 'mareo, confusión',   'estrés',               '37.3°C', 'Observación neurológica',  'Seguimiento por mareo y confusión leve.',                       61, 'Media',   'En sala',        'Sistema demo', '12,14,54,20', '18,31,49,41', 'Neurológico',            'violet'),
  (10003, 'María Rojas', '33', 'Femenino',  'malestar general',   'sin hallazgos',         '36.8°C', 'Orientación general',      'Sin patrón agudo claro. Revisión general recomendada.',         26, 'Estable', 'Alta pronta',    'Sistema demo', '18,18,14,50', '12,17,23,21', 'General',                'green');

-- ── Tabla de sesiones / notificaciones ────────────────
CREATE TABLE IF NOT EXISTS notificaciones (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  titulo    VARCHAR(200),
  texto     TEXT,
  usuario   VARCHAR(150),
  leida     TINYINT(1) DEFAULT 0,
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
