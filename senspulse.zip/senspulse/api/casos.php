<?php
// ═══════════════════════════════════════════════════════
//  SensPulse Pro — API de casos clínicos
//  GET  api/casos.php          → lista todos
//  POST api/casos.php          → guarda nuevo caso
//  DELETE api/casos.php?id=X   → elimina por id
// ═══════════════════════════════════════════════════════

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once 'config.php';
$conn = conectar();
$method = $_SERVER['REQUEST_METHOD'];

// ── GET: obtener historial ──────────────────────────────
if ($method === 'GET') {
    $res = $conn->query("SELECT * FROM casos ORDER BY creado_en DESC LIMIT 50");
    $casos = [];
    while ($row = $res->fetch_assoc()) {
        $casos[] = [
            'id'           => (int)$row['id'],
            'patient'      => $row['paciente'],
            'age'          => $row['edad'],
            'sex'          => $row['sexo'],
            'symptoms'     => $row['sintomas'],
            'risks'        => $row['riesgos'],
            'temperature'  => $row['temperatura'],
            'title'        => $row['titulo'],
            'text'         => $row['texto_result'],
            'score'        => (int)$row['score'],
            'priority'     => $row['prioridad'],
            'status'       => $row['estado'],
            'operator'     => $row['operador'],
            'chartValues'  => array_map('intval', explode(',', $row['chart_values'])),
            'trendValues'  => array_map('intval', explode(',', $row['trend_values'])),
            'tags'         => $row['tags'] ? explode(',', $row['tags']) : [],
            'colorClass'   => $row['color_class'],
            'createdAt'    => $row['creado_en'],
        ];
    }
    echo json_encode(['ok' => true, 'data' => $casos]);
}

// ── POST: guardar caso ─────────────────────────────────
elseif ($method === 'POST') {
    $d = json_decode(file_get_contents('php://input'), true);
    if (!$d || empty($d['patient'])) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Datos incompletos']);
        exit;
    }

    $stmt = $conn->prepare("
        INSERT INTO casos
          (paciente, edad, sexo, sintomas, riesgos, temperatura, titulo, texto_result,
           score, prioridad, estado, operador, chart_values, trend_values, tags, color_class)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ");

    $chartVals = is_array($d['chartValues'] ?? null) ? implode(',', $d['chartValues']) : '';
    $trendVals = is_array($d['trendValues'] ?? null) ? implode(',', $d['trendValues']) : '';
    $tags      = is_array($d['tags'] ?? null) ? implode(',', $d['tags']) : ($d['tags'] ?? '');
    $score     = (int)($d['score'] ?? 0);

    $stmt->bind_param('ssssssssississss',
        $d['patient'],
        $d['age']         ?? '',
        $d['sex']         ?? '',
        $d['symptoms']    ?? '',
        $d['risks']       ?? '',
        $d['temperature'] ?? '',
        $d['title']       ?? '',
        $d['text']        ?? '',
        $score,
        $d['priority']    ?? '',
        $d['status']      ?? '',
        $d['operator']    ?? '',
        $chartVals,
        $trendVals,
        $tags,
        $d['colorClass']  ?? ''
    );

    if ($stmt->execute()) {
        echo json_encode(['ok' => true, 'id' => $conn->insert_id]);
    } else {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => $stmt->error]);
    }
}

// ── DELETE: eliminar caso ──────────────────────────────
elseif ($method === 'DELETE') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'ID requerido']);
        exit;
    }
    $stmt = $conn->prepare("DELETE FROM casos WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    echo json_encode(['ok' => true, 'deleted' => $stmt->affected_rows]);
}

$conn->close();
