<?php
// ═══════════════════════════════════════════════════════
//  SensPulse Pro — Configuración de base de datos
//  Puerto XAMPP por defecto: 3306
// ═══════════════════════════════════════════════════════

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'senspulse');
define('DB_USER', 'root');
define('DB_PASS', '');      // XAMPP por defecto no tiene contraseña

function conectar() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, (int)DB_PORT);
    if ($conn->connect_error) {
        http_response_code(500);
        die(json_encode([
            'ok'    => false,
            'error' => 'No se pudo conectar a MySQL: ' . $conn->connect_error
        ]));
    }
    $conn->set_charset('utf8mb4');
    return $conn;
}
