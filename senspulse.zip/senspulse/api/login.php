<?php
// ═══════════════════════════════════════════════════════
//  SensPulse Pro — API de autenticación
//  POST api/login.php  { email, password, nombre?, rol? }
// ═══════════════════════════════════════════════════════

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once 'config.php';

$d = json_decode(file_get_contents('php://input'), true);
$email = strtolower(trim($d['email'] ?? ''));
$pass  = trim($d['password'] ?? '');
$nombre = trim($d['nombre'] ?? '');
$rol    = trim($d['rol']    ?? 'Médico');

if (!$email || !$pass) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Email y contraseña requeridos']);
    exit;
}

$conn = conectar();

// Buscar usuario registrado
$stmt = $conn->prepare("SELECT id, nombre, rol FROM usuarios WHERE email = ? AND password = SHA2(?, 256) LIMIT 1");
$stmt->bind_param('ss', $email, $pass);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows > 0) {
    $u = $res->fetch_assoc();
    echo json_encode(['ok' => true, 'nombre' => $u['nombre'], 'rol' => $u['rol'], 'tipo' => 'registrado']);
} else {
    // Login libre (cualquier email+pass+nombre válido)
    if ($nombre && $email && $pass) {
        // Registrar si no existe
        $chk = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $chk->bind_param('s', $email);
        $chk->execute();
        if ($chk->get_result()->num_rows === 0) {
            $ins = $conn->prepare("INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, SHA2(?, 256), ?)");
            $ins->bind_param('ssss', $nombre, $email, $pass, $rol);
            $ins->execute();
        }
        echo json_encode(['ok' => true, 'nombre' => $nombre, 'rol' => $rol, 'tipo' => 'nuevo']);
    } else {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Credenciales inválidas. Completa nombre, correo y contraseña.']);
    }
}

$conn->close();
