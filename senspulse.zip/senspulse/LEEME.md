# SensPulse Pro — Guía de instalación XAMPP
==============================================

## Requisitos
- XAMPP instalado (Windows/Mac/Linux)
- Puertos por defecto: Apache 80, MySQL 3306

---

## Paso 1 — Copiar archivos

Copia la carpeta **`senspulse/`** completa dentro de:

| Sistema  | Ruta htdocs                         |
|----------|-------------------------------------|
| Windows  | `C:\xampp\htdocs\senspulse\`        |
| Mac      | `/Applications/XAMPP/htdocs/senspulse/` |
| Linux    | `/opt/lampp/htdocs/senspulse/`      |

La estructura final debe quedar así:

```
htdocs/
└── senspulse/
    ├── index.html          ← página principal
    ├── .htaccess
    ├── api/
    │   ├── config.php
    │   ├── casos.php
    │   └── login.php
    └── sql/
        └── senspulse_db.sql
```

---

## Paso 2 — Crear la base de datos

1. Abre XAMPP Control Panel → inicia **Apache** y **MySQL**
2. Abre el navegador y entra a: **http://localhost/phpmyadmin**
3. Clic en **"Importar"** (pestaña superior)
4. Selecciona el archivo `sql/senspulse_db.sql`
5. Clic en **"Continuar"** → se creará la BD `senspulse` automáticamente

---

## Paso 3 — Abrir la aplicación

Abre el navegador y ve a:

**http://localhost/senspulse/**

### Credenciales demo:
- **Correo:** admin@senspulse.demo
- **Contraseña:** senspulse2026

---

## Indicador de conexión

En la barra superior verás el estado de la BD:

- 🟢 **MySQL OK** → conectado, datos en phpMyAdmin
- 🟡 **BD: local** → XAMPP no activo, datos en localStorage

---

## Solución de problemas

| Problema                        | Solución                                             |
|---------------------------------|------------------------------------------------------|
| "No se pudo conectar a MySQL"   | Verifica que MySQL esté iniciado en XAMPP            |
| Página en blanco                | Verifica que Apache esté iniciado en XAMPP           |
| Error 403                       | Asegúrate de que la carpeta esté dentro de htdocs    |
| MySQL con contraseña            | Edita `api/config.php` → cambia `DB_PASS`            |
| Puerto diferente al 80          | Usa `http://localhost:PUERTO/senspulse/`             |

---

## Estructura de la base de datos

- **`usuarios`** — Tabla de usuarios con login
- **`casos`** — Historial de casos clínicos
- **`notificaciones`** — Registro de alertas del sistema

Todos los datos guardados desde la app aparecen en **phpMyAdmin → senspulse**.
